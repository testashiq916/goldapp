<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\LogsDelpartAudit;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;
use Throwable;

class NativeCustomerController extends Controller
{
    use LogsDelpartAudit;

    /** In-process cache for Schema::hasTable / getColumnListing results */
    private static array $schemaCache = [];

    public function index(Request $request): View|RedirectResponse
    {
        if (!$this->isAuthorized($request)) {
            return redirect('/login');
        }

        $type = $this->normalizeType((string) $request->query('type', 'C'));
        $showList = (string) $request->query('list', '') === '1';
        if (!$showList) {
            return redirect('/customer/add?type=' . urlencode($type));
        }

        $search = trim((string) $request->query('search', ''));
        $noRemoved = (string) $request->query('noremoved', '1') !== '0';

        $customers = $this->queryCustomersByType($type, $search, $noRemoved);

        return view('native.customer.list', [
            'type' => $type,
            'typeInfo' => $this->getTypeInfo($type),
            'customers' => $customers,
            'search' => $search,
            'noRemoved' => $noRemoved,
            'message' => (string) session('flash_message', ''),
            'messageType' => (string) session('flash_type', ''),
        ]);
    }

    public function add(Request $request): View|RedirectResponse
    {
        if (!$this->isAuthorized($request)) {
            return redirect('/login');
        }

        $type = $this->normalizeType((string) $request->query('type', 'C'));
        return view($this->formView($type), [
            'type' => $type,
            'typeInfo' => $this->getTypeInfo($type),
            'isEdit' => false,
            'data' => ['code' => '', 'name' => '', 'grp' => $type === 'D' ? 'DEP' : ''],
            'lookups' => $this->loadLookups(),
        ]);
    }

    public function edit(Request $request): View|RedirectResponse
    {
        if (!$this->isAuthorized($request)) {
            return redirect('/login');
        }

        $type = $this->normalizeType((string) $request->query('type', 'C'));
        $code = trim((string) $request->query('code', ''));
        if ($code === '') {
            return redirect('/customer/add?type=' . urlencode($type));
        }

        $data = $this->getCustomerByCode($code);
        if (!$data) {
            return redirect('/customer?type=' . urlencode($type) . '&list=1')
                ->with('flash_message', 'Record not found')
                ->with('flash_type', 'error');
        }

        return view($this->formView($type), [
            'type' => $type,
            'typeInfo' => $this->getTypeInfo($type),
            'isEdit' => true,
            'data' => $data,
            'lookups' => $this->loadLookups(),
        ]);
    }

    public function deletePage(Request $request): RedirectResponse
    {
        if (!$this->isAuthorized($request)) {
            return redirect('/login');
        }

        $type = $this->normalizeType((string) $request->query('type', 'C'));
        $code = trim((string) $request->query('code', ''));
        if ($code === '') {
            return redirect('/customer?type=' . urlencode($type) . '&list=1');
        }

        $resp = $this->delete($request->merge(['code' => $code]));
        $payload = $resp->getData(true);
        return redirect('/customer?type=' . urlencode($type) . '&list=1')
            ->with('flash_message', (string) ($payload['message'] ?? 'Done'))
            ->with('flash_type', !empty($payload['success']) ? 'success' : 'error');
    }

    public function picture(Request $request): Response
    {
        if (!$this->isAuthorized($request)) {
            return response('', 401);
        }

        $code = trim((string) $request->query('code', ''));
        if ($code === '' || !self::hasTable('clientspict')) {
            return response('', 404);
        }

        $row = DB::table('clientspict')->select(['pict'])->where('code', $code)->first();
        $blob = (string) ($row->pict ?? '');
        if ($blob === '') {
            return response('', 404);
        }

        return response($blob, 200, ['Content-Type' => 'image/jpeg']);
    }

    public function nextCode(Request $request): JsonResponse
    {
        if (!$this->isAuthorized($request)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $type = strtoupper(trim((string) $request->query('type', 'C')));
        if (!in_array($type, ['C', 'S', 'F', 'D', 'G', 'R', 'J'], true)) {
            $type = 'C';
        }

        try {
            $code = $this->getNextAutoCode($type);
            return response()->json(['success' => true, 'code' => $code]);
        } catch (Throwable $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function get(Request $request): JsonResponse
    {
        if (!$this->isAuthorized($request)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $code = trim((string) $request->query('code', ''));
        if ($code === '') {
            return response()->json(['success' => false, 'message' => 'Code is required'], 400);
        }

        $row = $this->getCustomerByCode($code);
        if ($row === null) {
            return response()->json(['success' => false, 'message' => 'Record not found'], 404);
        }

        return response()->json(['success' => true, 'data' => $row]);
    }

    public function checkPhone(Request $request): JsonResponse
    {
        if (!$this->isAuthorized($request)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $phone = trim((string) $request->input('phone', $request->query('phone', '')));
        $code = trim((string) $request->input('code', $request->query('code', '')));
        if ($phone === '') {
            return response()->json(['exists' => false]);
        }

        $dup = DB::table('clients')
            ->select(['code', 'name', 'addr1'])
            ->where(function ($q) use ($phone) {
                $q->where('telephone', $phone)->orWhere('mobile', $phone);
            })
            ->when($code !== '', fn ($q) => $q->where('code', '<>', $code))
            ->first();

        if ($dup) {
            $details = trim(sprintf('%s - %s, %s', $dup->code ?? '', $dup->name ?? '', $dup->addr1 ?? ''), ' ,');
            return response()->json(['exists' => true, 'details' => $details]);
        }

        return response()->json(['exists' => false]);
    }

    public function checkIdNo(Request $request): JsonResponse
    {
        if (!$this->isAuthorized($request)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $idno = trim((string) $request->input('idno', $request->query('idno', '')));
        $code = trim((string) $request->input('code', $request->query('code', '')));
        if ($idno === '') {
            return response()->json(['exists' => false]);
        }

        $dup = DB::table('clients')
            ->select(['name'])
            ->where('idno', $idno)
            ->when($code !== '', fn ($q) => $q->where('code', '<>', $code))
            ->first();

        if ($dup) {
            return response()->json(['exists' => true, 'name' => (string) ($dup->name ?? '')]);
        }

        return response()->json(['exists' => false]);
    }

    public function save(Request $request): JsonResponse
    {
        if (!$this->isAuthorized($request)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $payload = $this->readPayload($request);
        $advancedPayload = [];
        if (isset($payload['advanced_payload'])) {
            $decoded = json_decode((string) $payload['advanced_payload'], true);
            if (is_array($decoded)) {
                $advancedPayload = $decoded;
            }
        }
        $code = strtoupper(trim((string) ($payload['code'] ?? '')));
        $type = strtoupper(trim((string) ($payload['type'] ?? $payload['ctype'] ?? 'C')));
        if ($code === '') {
            return response()->json(['success' => false, 'message' => 'Code is required'], 400);
        }
        if (trim((string) ($payload['name'] ?? '')) === '') {
            return response()->json(['success' => false, 'message' => 'Name is required'], 400);
        }

        $isDepositor = $type === 'D';
        if ($isDepositor) {
            $type = 'C';
            $payload['grp'] = 'DEP';
        }

        $exists = DB::table('clients')->where('code', $code)->exists();

        $clientRow = $this->buildClientRow($payload, $code, $type);

        DB::beginTransaction();
        try {
            if ($exists) {
                DB::table('clients')->where('code', $code)->update($clientRow);
            } else {
                DB::table('clients')->insert($clientRow);
            }

            $this->upsertAccountM($clientRow, $payload);
            $this->upsertClientGs($code, $payload, $type);
            $this->upsertAdvanced($code, $advancedPayload);
            $this->upsertPhoto($request, $code);
            DB::commit();
        } catch (Throwable $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Error: ' . $e->getMessage()], 400);
        }

        $label = $this->getTypeInfo($isDepositor ? 'D' : $type)['title'];
        $this->logDelpart($request, $label . '(' . $code . ') ' . ($exists ? 'Updated' : 'Added'), ['utype' => $exists ? 'E' : 'A', 'ttype' => 'R']);
        $saved = $this->getCustomerByCode($code);
        return response()->json([
            'success' => true,
            'message' => $exists ? 'Customer updated successfully' : 'Customer added successfully',
            'data' => $saved,
        ]);
    }

    public function delete(Request $request): JsonResponse
    {
        if (!$this->isAuthorized($request)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 401);
        }

        $payload = $this->readPayload($request);
        $code = trim((string) ($payload['code'] ?? ''));
        if ($code === '') {
            return response()->json(['success' => false, 'message' => 'Code is required'], 400);
        }

        if (DB::table('daybook')->where('accode', $code)->exists()) {
            return response()->json(['success' => false, 'message' => 'Transactions exist. Cannot delete this code.'], 400);
        }

        DB::beginTransaction();
        try {
            DB::table('clients')->where('code', $code)->delete();
            DB::table('accountm')->where('accode', $code)->delete();
            if (self::hasTable('clientsgs')) {
                DB::table('clientsgs')->where('code', $code)->delete();
            }
            if (self::hasTable('clientspict')) {
                DB::table('clientspict')->where('code', $code)->delete();
            }
            if (self::hasTable('clients_advanced')) {
                DB::table('clients_advanced')->where('code', $code)->delete();
            }
            DB::commit();
        } catch (Throwable $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Error: ' . $e->getMessage()], 400);
        }

        $this->logDelpart($request, 'Customer(' . $code . ') Deleted', ['utype' => 'D', 'ttype' => 'R']);
        return response()->json(['success' => true, 'message' => 'Customer deleted successfully']);
    }

    public function importCsv(Request $request): RedirectResponse
    {
        if (!$this->isAuthorized($request)) {
            return redirect('/login');
        }

        $type = $this->normalizeType((string) $request->input('type', 'C'));
        if (!in_array($type, ['C', 'S', 'G'], true)) {
            return redirect('/customer?type=' . urlencode($type) . '&list=1')
                ->with('flash_message', 'Import is available only for customers, suppliers, and smiths')
                ->with('flash_type', 'error');
        }

        $file = $request->file('csv_file');
        if (!$file instanceof UploadedFile || !$file->isValid()) {
            return redirect('/customer?type=' . urlencode($type) . '&list=1')
                ->with('flash_message', 'Please choose a valid CSV file')
                ->with('flash_type', 'error');
        }

        $ext = strtolower((string) $file->getClientOriginalExtension());
        if (!in_array($ext, ['csv', 'txt'], true)) {
            return redirect('/customer?type=' . urlencode($type) . '&list=1')
                ->with('flash_message', 'Only CSV files are allowed')
                ->with('flash_type', 'error');
        }

        try {
            $summary = $this->runCsvImport($file, $type);
        } catch (Throwable $e) {
            return redirect('/customer?type=' . urlencode($type) . '&list=1')
                ->with('flash_message', 'Import failed: ' . $e->getMessage())
                ->with('flash_type', 'error');
        }

        $message = sprintf(
            '%s import completed. Imported: %d, Skipped: %d',
            $this->getTypeInfo($type)['title'],
            $summary['imported'],
            $summary['skipped']
        );
        if (!empty($summary['errors'])) {
            $message .= '. Errors: ' . implode(' | ', array_slice($summary['errors'], 0, 5));
            if (count($summary['errors']) > 5) {
                $message .= ' ...';
            }
        }

        $this->logDelpart($request, $this->getTypeInfo($type)['title'] . ' CSV Import', ['utype' => 'A', 'ttype' => 'R']);

        return redirect('/customer?type=' . urlencode($type) . '&list=1')
            ->with('flash_message', $message)
            ->with('flash_type', empty($summary['errors']) ? 'success' : 'error');
    }

    private function readPayload(Request $request): array
    {
        $json = $request->json()->all();
        if (is_array($json) && !empty($json)) {
            return $json;
        }
        return $request->all();
    }

    private function isAuthorized(Request $request): bool
    {
        return (string) ($request->session()->get('user_code') ?? '') !== '';
    }

    private function formView(string $type): string
    {
        return match (true) {
            in_array($type, ['G', 'R', 'J'], true) => 'native.customer.form-smith',
            $type === 'D' => 'native.customer.form-depositor',
            default => 'native.customer.form',
        };
    }

    private function normalizeType(string $type): string
    {
        $type = strtoupper(trim($type));
        return in_array($type, ['C', 'S', 'F', 'D', 'G', 'R', 'J'], true) ? $type : 'C';
    }

    private function getTypeInfo(string $type): array
    {
        $types = [
            'C' => ['title' => 'Customer', 'plural' => 'Customers'],
            'S' => ['title' => 'Supplier', 'plural' => 'Suppliers'],
            'F' => ['title' => 'Staff', 'plural' => 'Staff'],
            'D' => ['title' => 'Depositor', 'plural' => 'Depositors'],
            'G' => ['title' => 'Goldsmith', 'plural' => 'Goldsmiths'],
            'R' => ['title' => 'Refiner', 'plural' => 'Refiners'],
            'J' => ['title' => 'Jewellery', 'plural' => 'Jewellery'],
        ];
        return $types[$type] ?? $types['C'];
    }

    private function queryCustomersByType(string $type, string $search, bool $noRemoved): array
    {
        $q = DB::table('clients')
            ->select(['code', 'name', 'mobile', 'telephone', 'city', 'addr1', 'ctype', 'grp', 'removed']);

        if ($type === 'D') {
            $q->where('ctype', 'C')->where(function ($x) {
                $x->whereRaw("LEFT(COALESCE(grp,''),3) = 'DEP'");
                if (self::hasColumn('clients', 'dcount')) {
                    $x->orWhere('dcount', '>', 0);
                }
            });
        } else {
            $q->where('ctype', $type);
        }

        if ($noRemoved && self::hasColumn('clients', 'removed')) {
            $q->where(function ($x) {
                $x->where('removed', '<>', 1)->orWhereNull('removed');
            });
        }

        if ($search !== '') {
            $s = '%' . $search . '%';
            $q->where(function ($x) use ($s) {
                $x->where('code', 'like', $s)
                    ->orWhere('name', 'like', $s)
                    ->orWhere('mobile', 'like', $s)
                    ->orWhere('telephone', 'like', $s)
                    ->orWhere('city', 'like', $s)
                    ->orWhere('addr1', 'like', $s);
            });
        }

        return $q->orderBy('name')->limit(300)->get()->map(fn ($r) => (array) $r)->all();
    }

    private function loadLookups(): array
    {
        $salesmen = self::hasTable('sman')
            ? DB::table('sman')->select(['code', 'name'])->orderBy('name')->get()->map(fn ($r) => (array) $r)->all()
            : [];
        $accountGroups = self::hasTable('accountg')
            ? DB::table('accountg')->select(['grcode as code', 'name'])->orderBy('name')->get()->map(fn ($r) => (array) $r)->all()
            : [];
        $bsHeads = self::hasTable('accountgbs')
            ? DB::table('accountgbs')->select(['hcode as code', 'hname as name'])->orderBy('hname')->get()->map(fn ($r) => (array) $r)->all()
            : [];
        $states = [];
        // Primary source: `state` table (code, name) as requested.
        if (self::hasTable('state')) {
            $stateCols = array_keys(self::tableColumns('state'));
            $codeCol = in_array('code', $stateCols, true) ? 'code' : (in_array('state', $stateCols, true) ? 'state' : null);
            $nameCol = in_array('name', $stateCols, true) ? 'name' : (in_array('state', $stateCols, true) ? 'state' : null);
            if ($codeCol && $nameCol) {
                $states = DB::table('state')
                    ->selectRaw("{$codeCol} as code, {$nameCol} as name")
                    ->whereNotNull($codeCol)
                    ->where($codeCol, '<>', '')
                    ->distinct()
                    ->orderBy($codeCol)
                    ->get()
                    ->map(fn ($r) => (array) $r)
                    ->all();
            }
        }
        if (empty($states) && self::hasTable('statestate')) {
            $states = DB::table('statestate')
                ->select(['state as code', 'state as name'])
                ->whereNotNull('state')
                ->distinct()
                ->orderBy('state')
                ->get()
                ->map(fn ($r) => (array) $r)
                ->all();
        }
        if (empty($states)) {
            $states = DB::table('clients')
                ->selectRaw("state as code, state as name")
                ->whereNotNull('state')
                ->where('state', '<>', '')
                ->distinct()
                ->orderBy('state')
                ->get()
                ->map(fn ($r) => (array) $r)
                ->all();
        }
        $routes = self::hasTable('route')
            ? DB::table('route')->select(['code', 'name'])->orderBy('code')->get()->map(fn ($r) => (array) $r)->all()
            : [];
        $areas = self::hasTable('area')
            ? DB::table('area')->select(['code', 'name'])->orderBy('code')->get()->map(fn ($r) => (array) $r)->all()
            : [];
        return [
            'salesmen' => $salesmen,
            'accountGroups' => $accountGroups,
            'bsHeads' => $bsHeads,
            'states' => $states,
            'routes' => $routes,
            'areas' => $areas,
        ];
    }

    private function getCustomerByCode(string $code): ?array
    {
        $row = DB::table('clients')->where('code', $code)->first();
        if (!$row) {
            return null;
        }
        $data = (array) $row;

        if (self::hasTable('accountm')) {
            $ac = DB::table('accountm')->where('accode', $code)->first();
            if ($ac) {
                $acArr = (array) $ac;
                $data['acgrp'] = $acArr['grcode'] ?? null;
                $data['bshead'] = $acArr['bshead'] ?? null;
                $data['ac_blocked'] = $acArr['blocked'] ?? null;
            }
        }

        if (self::hasTable('clientsgs')) {
            $gs = DB::table('clientsgs')->where('code', $code)->first();
            if ($gs) {
                $data = array_merge($data, (array) $gs);
            }
        }

        if (self::hasTable('clients_advanced')) {
            $adv = DB::table('clients_advanced')->where('code', $code)->first();
            $data['advanced'] = $adv ? (array) $adv : [];
        } else {
            $data['advanced'] = [];
        }

        return $data;
    }

    private function getNextAutoCode(string $type): string
    {
        $isDepositor = $type === 'D';
        if ($isDepositor) {
            $type = 'C';
        }

        if ($type === 'C') {
            $lastNo = (int) (DB::table('generali')->where('code', 'CLASTNO')->value('cvalue') ?? 0);
            $prefix = trim((string) (DB::table('generals')->where('code', 'CPREFIX')->value('cvalue') ?? 'C'));
        } else {
            $lastNo = (int) (DB::table('generali')->where('code', 'SLASTNO')->value('cvalue') ?? 0);
            $prefix = trim((string) (DB::table('generals')->where('code', 'SPREFIX')->value('cvalue') ?? $type));
        }

        if ($prefix === '') {
            $prefix = $type;
        }
        if ($isDepositor) {
            $prefix = 'C';
        }

        $maxCode = (string) (DB::table('clients')
            ->where('code', 'regexp', '^' . preg_quote($prefix, '/') . '[0-9]+$')
            ->max('code') ?? '');
        if (preg_match('/([0-9]+)$/', $maxCode, $m)) {
            $derived = (int) $m[1];
            if ($derived > $lastNo) {
                $lastNo = $derived;
            }
        }

        return $prefix . str_pad((string) ($lastNo + 1), 4, '0', STR_PAD_LEFT);
    }

    private function buildClientRow(array $data, string $code, string $type): array
    {
        $opBalance = (float) ($data['opbalance'] ?? 0);
        $opBalance = strtolower((string) ($data['balance_type'] ?? 'debit')) === 'credit' ? abs($opBalance) : -abs($opBalance);
        $opBalanceB = (float) ($data['opbalanceb'] ?? 0);
        $opBalanceB = strtolower((string) ($data['balance_type_b'] ?? 'debit')) === 'credit' ? abs($opBalanceB) : -abs($opBalanceB);
        $weight = (float) ($data['opweight'] ?? 0);
        $weight = strtolower((string) ($data['weight_type'] ?? 'debit')) === 'credit' ? abs($weight) : -abs($weight);
        $depWeight = (float) ($data['opdepwgtbal'] ?? 0);
        $depWeight = strtolower((string) ($data['depweight_type'] ?? 'debit')) === 'credit' ? abs($depWeight) : -abs($depWeight);
        [$addr1, $addr2, $addr3] = $this->normalizeAddressLines(
            (string) ($data['addr1'] ?? ''),
            (string) ($data['addr2'] ?? ''),
            (string) ($data['addr3'] ?? '')
        );

        $row = [
            'code' => $code,
            'name' => substr(trim((string) ($data['name'] ?? '')), 0, 40),
            'addr1' => $addr1,
            'addr2' => $addr2,
            'addr3' => $addr3,
            'city' => trim((string) ($data['city'] ?? '')),
            'telephone' => trim((string) ($data['telephone'] ?? '')),
            'mobile' => trim((string) ($data['mobile'] ?? '')),
            'email' => trim((string) ($data['email'] ?? '')),
            'pin' => trim((string) ($data['pin'] ?? '')),
            'state' => trim((string) ($data['state'] ?? '')),
            'panadhar' => trim((string) ($data['panadhar'] ?? '')),
            'tin' => trim((string) ($data['tin'] ?? '')),
            'cst' => trim((string) ($data['cst'] ?? '')),
            'opbalance' => $opBalance,
            'opbalanceb' => $opBalanceB,
            'ctype' => $type,
            'control' => 1,
            'removed' => isset($data['removed']) ? 1 : 0,
            'blocked' => isset($data['blocked']) ? 'Y' : 'N',
            'salary' => (float) ($data['salary'] ?? 0),
            'cocode' => trim((string) ($data['cocode'] ?? '')),
            'grp' => trim((string) ($data['grp'] ?? 'O')),
            'route' => trim((string) ($data['route'] ?? '')),
            'carea' => trim((string) ($data['carea'] ?? ($data['area'] ?? ''))),
            'adate' => $this->normalizeDate($data['adate'] ?? ''),
            'duedate' => $this->normalizeDate($data['duedate'] ?? ''),
            'cutrate' => (float) ($data['cutrate'] ?? 0),
            'colncomn' => (float) ($data['colncomn'] ?? 0),
            'opweight' => $weight,
            'opdepwgtbal' => $depWeight,
            'idno' => trim((string) ($data['idno'] ?? '')),
            'religion' => trim((string) ($data['religion'] ?? '')),
            'note' => trim((string) ($data['note'] ?? '')),
            'coparty' => isset($data['coparty']) ? 'Y' : 'N',
            'pcard' => trim((string) ($data['pcard'] ?? '')),
            'smcode' => trim((string) ($data['smcode'] ?? '')),
            'pospwd' => trim((string) ($data['pospwd'] ?? '')),
            'agent' => isset($data['agent']) ? 'Y' : 'N',
            'oppcardpoints' => (float) ($data['oppcardpoints'] ?? 0),
            'pcardno' => trim((string) ($data['pcardno'] ?? '')),
            'approval' => isset($data['approval']) ? 'Y' : 'N',
            'homemobile' => trim((string) ($data['homemobile'] ?? '')),
            'distance' => (int) ($data['distance'] ?? 0),
            'billdate' => $this->normalizeDate($data['billdate'] ?? ''),
        ];

        $columns = self::tableColumns('clients');
        return array_filter($row, static fn ($v, $k) => array_key_exists($k, $columns), ARRAY_FILTER_USE_BOTH);
    }

    private function runCsvImport(UploadedFile $file, string $type): array
    {
        $handle = fopen($file->getRealPath(), 'r');
        if ($handle === false) {
            throw new \RuntimeException('Cannot read uploaded file');
        }

        $header = fgetcsv($handle);
        if (!is_array($header) || $header === []) {
            fclose($handle);
            throw new \RuntimeException('CSV file is empty');
        }

        $normalizedHeader = array_map(fn ($value) => $this->normalizeImportHeader((string) $value), $header);
        $imported = 0;
        $skipped = 0;
        $errors = [];

        $lineNo = 1;
        while (($row = fgetcsv($handle)) !== false) {
            $lineNo++;
            $mapped = [];
            foreach ($normalizedHeader as $index => $name) {
                if ($name === '') {
                    continue;
                }
                $mapped[$name] = trim((string) ($row[$index] ?? ''));
            }

            if ($this->isImportRowBlank($mapped)) {
                $skipped++;
                continue;
            }

            if (strtoupper(substr((string) ($mapped['code'] ?? ''), 0, 5)) === 'TOTAL') {
                $skipped++;
                continue;
            }

            DB::beginTransaction();
            try {
                if ($this->importClientRow($mapped, $type)) {
                    $imported++;
                } else {
                    $skipped++;
                }
                DB::commit();
            } catch (Throwable $e) {
                DB::rollBack();
                $errors[] = 'Line ' . $lineNo . ': ' . $e->getMessage();
            }
        }

        fclose($handle);

        return [
            'imported' => $imported,
            'skipped' => $skipped,
            'errors' => $errors,
        ];
    }

    private function importClientRow(array $row, string $type): bool
    {
        $code = strtoupper(substr(trim((string) ($row['code'] ?? '')), 0, 10));
        $name = trim((string) ($row['name'] ?? ''));
        if ($name === '') {
            return false;
        }

        if ($code === '') {
            $code = $this->reserveNextCode($type);
        }

        if (DB::table('clients')->where('code', $code)->exists()) {
            return false;
        }

        $openingBalance = $this->parseImportNumber($row['opening_balance'] ?? '0');
        if ($type === 'S') {
            $openingBalance = -$openingBalance;
        }

        $groupDefault = $type === 'S' ? 'SUNCR' : 'SUNDB';
        $accountGroup = strtoupper(trim((string) ($row['account_group'] ?? $groupDefault)));
        $bsHead = strtoupper(trim((string) ($row['bs_head'] ?? $accountGroup ?: $groupDefault)));
        $createdDate = $this->normalizeDate($row['creation_date'] ?? '') ?? date('Y-m-d');

        $payload = [
            'name' => $name,
            'addr1' => (string) ($row['address_1'] ?? ''),
            'addr2' => (string) ($row['address_2'] ?? ''),
            'addr3' => (string) ($row['address_3'] ?? ''),
            'mobile' => (string) ($row['mobile'] ?? ''),
            'telephone' => (string) ($row['telephone'] ?? ($row['mobile'] ?? '')),
            'opbalance' => abs($openingBalance),
            'balance_type' => $openingBalance >= 0 ? 'credit' : 'debit',
            'opbalanceb' => abs($openingBalance),
            'balance_type_b' => $openingBalance >= 0 ? 'credit' : 'debit',
            'grp' => $type === 'C' ? 'SCHM' : '',
            'adate' => $createdDate,
            'billdate' => $createdDate,
            'acgrp' => $accountGroup !== '' ? $accountGroup : $groupDefault,
            'bshead' => $bsHead !== '' ? $bsHead : $groupDefault,
        ];

        $clientRow = $this->buildClientRow($payload, $code, $type);
        DB::table('clients')->insert($clientRow);

        $this->upsertAccountM($clientRow, $payload);

        if ($type === 'C' && self::hasTable('clients_kuridet')) {
            $this->insertClientKuriDet($code, $createdDate, (float) ($clientRow['opbalance'] ?? 0), (string) ($row['kuri_type'] ?? ''));
        }

        if (in_array($type, ['G', 'R', 'J'], true)) {
            $this->upsertClientGs($code, $payload, $type);
        }

        return true;
    }

    private function insertClientKuriDet(string $code, string $createdDate, float $openingBalance, string $kuriType): void
    {
        $row = [
            'code' => $code,
            'startdate' => $createdDate,
            'instnos' => 0,
            'instamt' => 0,
            'totamt' => 0,
            'bonus' => 0,
            'finished' => 'N',
            'kuritype' => trim($kuriType),
            'intrate' => 0,
            'colntype' => '',
            'colnagent' => '',
            'matdate' => null,
            'wadate' => null,
            'bdate' => null,
            'nomname' => '',
            'nomaddr' => '',
            'nomrelation' => '',
            'showwgtdet' => 'N',
            'opwgt' => 0,
            'opwgtb' => 0,
            'collnopbal' => $openingBalance,
            'custlinkac' => '',
            'collnminamt' => 0,
            'collnmaxamt' => 0,
        ];

        $columns = self::tableColumns('clients_kuridet');
        $row = array_filter($row, static fn ($v, $k) => array_key_exists($k, $columns), ARRAY_FILTER_USE_BOTH);
        if (!empty($row)) {
            DB::table('clients_kuridet')->insert($row);
        }
    }

    private function reserveNextCode(string $type): string
    {
        $counterCode = $type === 'C' ? 'CLASTNO' : 'SLASTNO';
        $prefixCode = $type === 'C' ? 'CPREFIX' : 'SPREFIX';
        $fallbackPrefix = $type === 'C' ? 'C' : 'S';

        $current = (int) (DB::table('generali')->where('code', $counterCode)->lockForUpdate()->value('cvalue') ?? 0);
        $prefix = trim((string) (DB::table('generals')->where('code', $prefixCode)->value('cvalue') ?? $fallbackPrefix));
        if ($prefix === '') {
            $prefix = $fallbackPrefix;
        }

        $next = $current + 1;
        DB::table('generali')->updateOrInsert(['code' => $counterCode], ['cvalue' => $next]);

        return strtoupper($prefix . str_pad((string) $next, 4, '0', STR_PAD_LEFT));
    }

    private function normalizeImportHeader(string $header): string
    {
        $header = strtolower(trim($header));
        $header = str_replace(['.', '-', '/', '\\'], ' ', $header);
        $header = preg_replace('/\s+/', ' ', $header) ?? $header;

        return match ($header) {
            'code', 'customer code', 'supplier code' => 'code',
            'name', 'customer name', 'supplier name' => 'name',
            'address 1', 'address1', 'addr1' => 'address_1',
            'address 2', 'address2', 'addr2' => 'address_2',
            'address 3', 'address3', 'addr3' => 'address_3',
            'mobile number', 'mobile', 'phone', 'phone number' => 'mobile',
            'telephone', 'tel', 'telephone number' => 'telephone',
            'opening balance', 'opbalance', 'op balance' => 'opening_balance',
            'cus creation date', 'creation date', 'created date', 'date', 'adate', 'billdate' => 'creation_date',
            'account group', 'acgrp', 'grp', 'group' => 'account_group',
            'bs head', 'bshead', 'shedgrp' => 'bs_head',
            'kuri type', 'kuritype', 'scheme type' => 'kuri_type',
            default => str_replace(' ', '_', $header),
        };
    }

    private function isImportRowBlank(array $row): bool
    {
        foreach (['code', 'name', 'address_1', 'address_2', 'address_3', 'mobile', 'opening_balance', 'creation_date'] as $key) {
            if (trim((string) ($row[$key] ?? '')) !== '') {
                return false;
            }
        }

        return true;
    }

    private function parseImportNumber(mixed $value): float
    {
        $value = trim((string) $value);
        if ($value === '') {
            return 0.0;
        }

        $normalized = str_replace([',', ' '], '', $value);
        if (!is_numeric($normalized)) {
            return 0.0;
        }

        return (float) $normalized;
    }

    private function normalizeAddressLines(string $addr1, string $addr2 = '', string $addr3 = ''): array
    {
        $limit = 30;
        $lines = [
            trim($addr1),
            trim($addr2),
            trim($addr3),
        ];

        if (strlen($lines[0]) <= $limit && strlen($lines[1]) <= $limit && strlen($lines[2]) <= $limit) {
            return $lines;
        }

        $combined = trim(implode(' ', array_filter($lines, static fn ($line) => $line !== '')));
        if ($combined === '') {
            return ['', '', ''];
        }

        $chunks = [];
        while ($combined !== '' && count($chunks) < 3) {
            if (strlen($combined) <= $limit) {
                $chunks[] = $combined;
                break;
            }

            $slice = substr($combined, 0, $limit + 1);
            $breakAt = strrpos($slice, ' ');
            if ($breakAt === false || $breakAt < 10) {
                $breakAt = $limit;
            }

            $chunks[] = trim(substr($combined, 0, $breakAt));
            $combined = ltrim(substr($combined, $breakAt));
        }

        while (count($chunks) < 3) {
            $chunks[] = '';
        }

        return [
            substr($chunks[0], 0, $limit),
            substr($chunks[1], 0, $limit),
            substr($chunks[2], 0, $limit),
        ];
    }

    private function upsertAccountM(array $clientData, array $payload): void
    {
        if (!self::hasTable('accountm')) {
            return;
        }

        $code = (string) $clientData['code'];
        $name = substr(((string) ($clientData['name'] ?? '')) . '(' . $code . ')', 0, 30);
        $ctype = strtoupper((string) ($clientData['ctype'] ?? 'C'));
        $actype1 = $ctype === 'C' ? 'A' : 'L';
        $defaultGroup = in_array($ctype, ['C', 'D', 'J'], true) ? 'SUNDB' : 'SUNCR';
        $grcode = trim((string) ($payload['acgrp'] ?? $clientData['grp'] ?? $defaultGroup));
        if ($grcode === '') {
            $grcode = $defaultGroup;
        }
        $bshead = trim((string) ($payload['bshead'] ?? $grcode));
        if ($bshead === '') {
            $bshead = $defaultGroup;
        }

        $row = [
            'accode' => $code,
            'name' => $name,
            'opbal' => (float) ($clientData['opbalance'] ?? 0),
            'opbalb' => (float) ($clientData['opbalanceb'] ?? 0),
            'actype1' => $actype1,
            'actype2' => $ctype,
            'control' => (int) ($clientData['control'] ?? 1),
            'grcode' => $grcode,
            'bshead' => $bshead,
            'shedgrp' => $bshead,
            'hlp' => 1,
            'sp' => 0,
            'removed' => (int) ($clientData['removed'] ?? 0),
            'blocked' => (string) ($clientData['blocked'] ?? 'N'),
        ];

        $columns = self::tableColumns('accountm');
        $row = array_filter($row, static fn ($v, $k) => array_key_exists($k, $columns), ARRAY_FILTER_USE_BOTH);

        $exists = DB::table('accountm')->where('accode', $code)->exists();
        if ($exists) {
            $updateRow = $row;
            unset($updateRow['accode']);
            if (!empty($updateRow)) {
                DB::table('accountm')->where('accode', $code)->update($updateRow);
            }
            return;
        }

        if (!empty($row)) {
            DB::table('accountm')->insert($row);
        }
    }

    private function upsertAdvanced(string $code, array $advanced): void
    {
        if ($advanced === [] || !self::hasTable('clients_advanced')) {
            return;
        }

        $base = ['code' => $code];
        $allowed = self::tableColumns('clients_advanced');

        $normalized = [];
        foreach ($advanced as $k => $v) {
            $key = trim((string) $k);
            if ($key === '' || !isset($allowed[$key])) {
                continue;
            }
            $normalized[$key] = is_string($v) ? trim($v) : $v;
        }

        $row = array_merge($base, $normalized);
        if (count($row) <= 1) {
            return;
        }

        DB::table('clients_advanced')->upsert([$row], ['code'], array_keys($normalized));
    }

    private function upsertClientGs(string $code, array $payload, string $type): void
    {
        if (!self::hasTable('clientsgs') || !in_array($type, ['G', 'R', 'J'], true)) {
            return;
        }

        $opWeight = (float) ($payload['opweight'] ?? 0);
        $opWeight = strtolower((string) ($payload['weight_type'] ?? 'debit')) === 'credit' ? abs($opWeight) : -abs($opWeight);

        $opWeightB = (float) ($payload['opweightb'] ?? 0);
        $opWeightB = strtolower((string) ($payload['weight_type_b'] ?? 'debit')) === 'credit' ? abs($opWeightB) : -abs($opWeightB);
        $roundupRaw = trim((string) ($payload['roundup'] ?? ''));
        if (strcasecmp($roundupRaw, 'Y') === 0) {
            $roundup = 1.0;
        } elseif (strcasecmp($roundupRaw, 'N') === 0 || $roundupRaw === '') {
            $roundup = 0.0;
        } else {
            $roundup = (float) $roundupRaw;
        }

        $row = [
            'code' => $code,
            'ctype' => $type,
            'wastage' => (float) ($payload['wastage'] ?? 0),
            'opweight' => $opWeight,
            'mcrate' => (float) ($payload['mcrate'] ?? 0),
            'opweightb' => $opWeightB,
            'opwgtamt' => (float) ($payload['opwgtamt'] ?? 0),
            'opwgtamtb' => (float) ($payload['opwgtamtb'] ?? 0),
            'acin24ct' => isset($payload['acin24ct']) ? 1 : 0,
            'deftouch' => (float) ($payload['deftouch'] ?? 0),
            'convtouch' => (float) ($payload['convtouch'] ?? 0),
            'email' => trim((string) ($payload['email'] ?? '')),
            'decround' => (int) ($payload['decround'] ?? 0),
            'roundup' => $roundup,
            'mcdecround' => (int) ($payload['mcdecround'] ?? 0),
            'silver' => isset($payload['silver']) ? 'Y' : 'N',
            'stocktouch' => (float) ($payload['stocktouch'] ?? 0),
            'intamt' => (float) ($payload['intamt'] ?? 0),
            'intwgt' => (float) ($payload['intwgt'] ?? 0),
        ];

        $columns = self::tableColumns('clientsgs');
        $row = array_filter($row, static fn ($v, $k) => array_key_exists($k, $columns), ARRAY_FILTER_USE_BOTH);
        if (count($row) <= 1) {
            return;
        }

        $exists = DB::table('clientsgs')->where('code', $code)->exists();
        if ($exists) {
            $updateRow = $row;
            unset($updateRow['code']);
            DB::table('clientsgs')->where('code', $code)->update($updateRow);
            return;
        }

        DB::table('clientsgs')->insert($row);
    }

    private function upsertPhoto(Request $request, string $code): void
    {
        if (!$request->hasFile('photo') || !self::hasTable('clientspict')) {
            return;
        }

        $file = $request->file('photo');
        if (!$file || !$file->isValid()) {
            return;
        }

        $blob = @file_get_contents($file->getRealPath());
        if ($blob === false || $blob === '') {
            return;
        }

        DB::table('clientspict')->upsert(
            [[
                'code' => $code,
                'pict' => $blob,
            ]],
            ['code'],
            ['pict']
        );
    }

    private static function hasTable(string $table): bool
    {
        return self::$schemaCache['t_' . $table] ??= Schema::hasTable($table);
    }

    private static function tableColumns(string $table): array
    {
        return self::$schemaCache['c_' . $table] ??= array_flip(Schema::getColumnListing($table));
    }

    private static function hasColumn(string $table, string $col): bool
    {
        return isset(self::tableColumns($table)[$col]);
    }

    private function normalizeDate(mixed $value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }

        foreach (['Y-m-d', 'd/m/Y', 'd-m-Y'] as $format) {
            $dt = \DateTime::createFromFormat($format, $value);
            if ($dt && $dt->format($format) === $value) {
                return $dt->format('Y-m-d');
            }
        }

        return null;
    }
}
