<?php

namespace App\Http\Controllers;

use App\Models\UserM;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class OwnerAppApiController extends Controller
{
    // ══════════════════════════════════════════════════════════════
    //  AUTH
    // ══════════════════════════════════════════════════════════════

    /** POST /api/owner/login  {user_code, password, database?} */
    public function login(Request $request): JsonResponse
    {
        $this->switchDatabase((string) ($request->input('database') ?? ''));

        $userCode = strtoupper(trim((string) $request->input('user_code', '')));
        $password  = trim((string) $request->input('password', ''));

        if ($password === '') {
            return response()->json(['ok' => false, 'message' => 'Password required'], 400);
        }
        if (!Schema::hasTable('userm')) {
            return response()->json(['ok' => false, 'message' => 'User table not found'], 500);
        }

        try {
            $user = $userCode !== ''
                ? UserM::authenticateForCode($userCode, $password)
                : UserM::authenticateLegacy($password);
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'message' => 'Auth error: ' . $e->getMessage()], 500);
        }

        if (!$user) {
            return response()->json(['ok' => false, 'message' => 'Invalid credentials'], 401);
        }

        $db    = (string) config('database.connections.mysql.database', '');
        $token = Str::random(64);

        Cache::put("owner_token:{$token}", [
            'user_code' => trim((string) $user->code),
            'user_name' => trim((string) $user->name),
            'database'  => $db,
        ], now()->addDays(7));

        // Get shop info
        $shopName = $this->getGeneral('SHOPNM') ?: 'Gold Plus';

        return response()->json([
            'ok'        => true,
            'token'     => $token,
            'user_code' => trim((string) $user->code),
            'user_name' => trim((string) $user->name),
            'database'  => $db,
            'shop_name' => $shopName,
        ]);
    }

    /** POST /api/owner/logout */
    public function logout(Request $request): JsonResponse
    {
        $token = $this->extractToken($request);
        if ($token) {
            Cache::forget("owner_token:{$token}");
        }
        return response()->json(['ok' => true]);
    }

    /** GET /api/owner/users?database= */
    public function users(Request $request): JsonResponse
    {
        $this->switchDatabase((string) ($request->query('database') ?? ''));

        if (!Schema::hasTable('userm')) {
            return response()->json(['ok' => true, 'users' => []]);
        }

        $cols = ['code', 'name'];
        foreach (['email', 'mobile'] as $c) {
            if (Schema::hasColumn('userm', $c)) $cols[] = $c;
        }

        $users = DB::table('userm')
            ->select($cols)
            ->orderBy('code')
            ->get()
            ->map(fn ($u) => [
                'code' => trim((string) ($u->code ?? '')),
                'name' => trim((string) ($u->name ?? '')),
            ])
            ->values()
            ->toArray();

        return response()->json(['ok' => true, 'users' => $users]);
    }

    /** GET /api/owner/shop-info?database= */
    public function shopInfo(Request $request): JsonResponse
    {
        $this->switchDatabase((string) ($request->query('database') ?? ''));

        return response()->json([
            'ok'        => true,
            'shop_name' => $this->getGeneral('SHOPNM'),
            'address'   => $this->getGeneral('SHOPADDR'),
            'phone'     => $this->getGeneral('SHOPPHONE'),
            'gstin'     => $this->getGeneral('GSTIN') ?: $this->getGeneral('GSTNO'),
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    //  DASHBOARD
    // ══════════════════════════════════════════════════════════════

    /** GET /api/owner/dashboard */
    public function dashboard(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->relaxGroupBy();

        $today = date('Y-m-d');
        $month = date('Y-m-01');

        $todaySales = 0.0; $monthSales = 0.0; $todayBills = 0;

        if (Schema::hasTable('salesm')) {
            // status is smallint: 1=active, 0=cancelled
            $statusCol = Schema::hasColumn('salesm', 'status') ? 'status' : null;
            $r = DB::table('salesm')
                ->selectRaw("COALESCE(SUM(netamt),0) as amt, COUNT(*) as cnt")
                ->where('tdate', $today)
                ->when($statusCol, fn ($q) => $q->where('status', '!=', 0))
                ->first();
            $todaySales = (float) ($r->amt ?? 0);
            $todayBills = (int) ($r->cnt ?? 0);

            $mr = DB::table('salesm')
                ->selectRaw("COALESCE(SUM(netamt),0) as amt")
                ->whereBetween('tdate', [$month, $today])
                ->when($statusCol, fn ($q) => $q->where('status', '!=', 0))
                ->first();
            $monthSales = (float) ($mr->amt ?? 0);
        }

        // Today's receipts from daybook (debit entries to CASH/BANK from clients)
        $todayReceipts = 0.0;
        if (Schema::hasTable('daybook')) {
            $rr = DB::table('daybook')
                ->selectRaw("COALESCE(SUM(CASE WHEN amount>0 THEN amount ELSE 0 END),0) as a")
                ->where('tdate', $today)
                ->where('control', 1)
                ->whereIn('accode', ['CASH', 'BANK', 'HDFC', 'SBI', 'AXIS'])
                ->first();
            $todayReceipts = (float) ($rr->a ?? 0);
        }

        // Total receivable = sum of positive customer balances from daybook
        $totalReceivable = 0.0;
        if (Schema::hasTable('daybook')) {
            $br = DB::table('daybook')
                ->selectRaw("accode, SUM(amount) as bal")
                ->where('control', 1)
                ->whereRaw("accode NOT IN ('CASH','RS','SLNA','WC-19015','CARA','BANK')")
                ->groupBy('accode')
                ->havingRaw("SUM(amount) > 0")
                ->get();
            $totalReceivable = (float) $br->sum('bal');
        }

        return response()->json([
            'ok'               => true,
            'today'            => $today,
            'today_sales'      => $todaySales,
            'today_bills'      => $todayBills,
            'month_sales'      => $monthSales,
            'today_receipts'   => $todayReceipts,
            'total_receivable' => $totalReceivable,
            'rates'            => $this->getCurrentRates(),
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    //  RECEIVABLE / PAYABLE
    // ══════════════════════════════════════════════════════════════

    /** GET /api/owner/receivable-payable?type=receivable&from=&to= */
    public function receivablePayable(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->relaxGroupBy();

        $type = trim((string) $request->query('type', 'receivable'));
        $from = $this->safeDate($request->query('from', ''), date('Y') . '-04-01');
        $to   = $this->safeDate($request->query('to', ''),   date('Y-m-d'));

        if (!Schema::hasTable('clients')) {
            return response()->json(['ok' => true, 'type' => $type, 'rows' => [], 'total' => 0, 'count' => 0]);
        }

        // Build balances from daybook (positive = receivable, negative = payable)
        $balances = [];
        if (Schema::hasTable('daybook')) {
            $dbRows = DB::table('daybook')
                ->selectRaw('TRIM(accode) as accode, SUM(amount) as bal')
                ->where('control', 1)
                ->groupBy('accode')
                ->havingRaw($type === 'receivable' ? 'SUM(amount) > 0.01' : 'SUM(amount) < -0.01')
                ->get();
            foreach ($dbRows as $dbr) {
                $balances[trim((string) $dbr->accode)] = (float) $dbr->bal;
            }
        }

        if (empty($balances)) {
            return response()->json(['ok' => true, 'type' => $type, 'rows' => [], 'total' => 0, 'count' => 0]);
        }

        // Fetch client names for those codes
        $codes = array_keys($balances);
        $clientMap = DB::table('clients')
            ->whereIn(DB::raw('TRIM(code)'), $codes)
            ->get(['code', 'name', 'mobile', 'carea'])
            ->keyBy(fn ($c) => trim((string) $c->code))
            ->toArray();

        $rows = [];
        foreach ($balances as $code => $bal) {
            $c = $clientMap[$code] ?? null;
            if (!$c && strlen($code) > 8) continue; // skip non-client codes (CASH, RS, etc.)
            $rows[] = [
                'code'      => $code,
                'name'      => $c ? trim((string) $c->name) : $code,
                'mobile'    => $c ? trim((string) ($c->mobile ?? '')) : '',
                'area'      => $c ? trim((string) ($c->carea ?? '')) : '',
                'balance'   => $bal,
                'last_bill' => null,
            ];
        }

        // Sort by absolute balance descending
        usort($rows, fn ($a, $b) => abs($b['balance']) <=> abs($a['balance']));
        $rows = array_slice($rows, 0, 300);

        $total = array_sum(array_column($rows, 'balance'));

        return response()->json([
            'ok'    => true,
            'type'  => $type,
            'rows'  => $rows,
            'total' => $total,
            'count' => count($rows),
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    //  STOCK SUMMARY
    // ══════════════════════════════════════════════════════════════

    /** GET /api/owner/stock-summary */
    public function stockSummary(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->relaxGroupBy();

        if (!Schema::hasTable('items')) {
            return response()->json(['ok' => true, 'rows' => [], 'totals' => []]);
        }

        // items table uses: weight (current stock wgt), qty (current stock qty), cost
        $hasGrp  = Schema::hasTable('itemgrp');
        $hasCost = Schema::hasColumn('items', 'cost');
        $hasWgt  = Schema::hasColumn('items', 'weight');
        $hasQty  = Schema::hasColumn('items', 'qty');

        $q = DB::table('items as i');
        if ($hasGrp) {
            $q->leftJoin('itemgrp as g', DB::raw('TRIM(g.code)'), '=', DB::raw('TRIM(i.grpcode)'));
        }

        $selects = [
            DB::raw('TRIM(i.grpcode) as grpcode'),
            $hasGrp
                ? DB::raw('COALESCE(TRIM(g.name), TRIM(i.grpcode)) as grpname')
                : DB::raw('TRIM(i.grpcode) as grpname'),
            $hasQty  ? DB::raw('SUM(COALESCE(i.qty,0)) as qty')      : DB::raw('0 as qty'),
            $hasWgt  ? DB::raw('SUM(COALESCE(i.weight,0)) as wgt')   : DB::raw('0 as wgt'),
            ($hasWgt && $hasCost)
                ? DB::raw('SUM(COALESCE(i.weight,0)*COALESCE(i.cost,0)) as cost_amt')
                : DB::raw('0 as cost_amt'),
        ];

        $rows = $q->select($selects)
            ->when($hasWgt || $hasQty, function ($q2) use ($hasWgt, $hasQty) {
                if ($hasWgt && $hasQty) {
                    $q2->whereRaw('COALESCE(i.weight,0)+COALESCE(i.qty,0) > 0');
                } elseif ($hasWgt) {
                    $q2->whereRaw('COALESCE(i.weight,0) > 0');
                } else {
                    $q2->whereRaw('COALESCE(i.qty,0) > 0');
                }
            })
            ->groupBy('i.grpcode')
            ->orderByDesc('wgt')
            ->get()
            ->map(fn ($r) => [
                'grpcode'  => (string) $r->grpcode,
                'grpname'  => (string) $r->grpname,
                'qty'      => (float) $r->qty,
                'wgt'      => (float) $r->wgt,
                'cost_amt' => (float) $r->cost_amt,
            ])
            ->toArray();

        $totals = [
            'qty'      => array_sum(array_column($rows, 'qty')),
            'wgt'      => array_sum(array_column($rows, 'wgt')),
            'cost_amt' => array_sum(array_column($rows, 'cost_amt')),
        ];

        return response()->json(['ok' => true, 'rows' => $rows, 'totals' => $totals]);
    }

    // ══════════════════════════════════════════════════════════════
    //  GOLDSMITH / SMITH SUMMARY
    // ══════════════════════════════════════════════════════════════

    /** GET /api/owner/goldsmith-summary?from=&to= */
    public function goldsmithSummary(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->relaxGroupBy();

        $from = $this->safeDate($request->query('from', ''), date('Y') . '-04-01');
        $to   = $this->safeDate($request->query('to', ''),   date('Y-m-d'));

        $rows = [];

        // Try goldsmith transactions table (GoldsmithTransactionsController data source)
        if (Schema::hasTable('goldsmithtransm')) {
            $rows = $this->smithFromGoldsmithtransm($from, $to);
        } elseif (Schema::hasTable('smithm')) {
            $rows = $this->smithFromSmithm($from, $to);
        }

        // Fallback: try clients with a type flag
        if (empty($rows) && Schema::hasTable('clients')) {
            $rows = $this->smithFromClients();
        }

        $totals = [
            'issued_wgt'   => array_sum(array_column($rows, 'issued_wgt')),
            'received_wgt' => array_sum(array_column($rows, 'received_wgt')),
            'balance_wgt'  => array_sum(array_column($rows, 'balance_wgt')),
            'amount'       => array_sum(array_column($rows, 'amount')),
        ];

        return response()->json(['ok' => true, 'rows' => $rows, 'totals' => $totals]);
    }

    // ══════════════════════════════════════════════════════════════
    //  ITEM MOVEMENT
    // ══════════════════════════════════════════════════════════════

    /** GET /api/owner/item-movement?from=&to= */
    public function itemMovement(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->relaxGroupBy();

        $from = $this->safeDate($request->query('from', ''), date('Y-m-01'));
        $to   = $this->safeDate($request->query('to', ''),   date('Y-m-d'));

        if (!Schema::hasTable('salesd') || !Schema::hasTable('salesm')) {
            return response()->json(['ok' => true, 'rows' => [], 'totals' => []]);
        }

        $hasItems = Schema::hasTable('items');
        $hasGrp   = Schema::hasTable('itemgrp');

        $q = DB::table('salesd as d')
            ->join('salesm as m', 'm.slno', '=', 'd.slno');

        if ($hasItems) {
            $q->leftJoin('items as i', DB::raw('TRIM(i.code)'), '=', DB::raw('TRIM(d.code)'));
            if ($hasGrp) {
                $q->leftJoin('itemgrp as g', DB::raw('TRIM(g.code)'), '=', DB::raw('TRIM(i.grpcode)'));
            }
        }

        $select = [
            DB::raw('TRIM(d.code) as item_code'),
            $hasItems
                ? DB::raw('COALESCE(TRIM(i.name), TRIM(d.code)) as item_name')
                : DB::raw('TRIM(d.code) as item_name'),
            ($hasItems && $hasGrp)
                ? DB::raw('COALESCE(TRIM(g.name), TRIM(i.grpcode),"—") as grp_name')
                : DB::raw('"—" as grp_name'),
            DB::raw('COUNT(DISTINCT m.slno) as bill_count'),
            DB::raw('SUM(COALESCE(d.qty,0)) as qty'),
            DB::raw('SUM(COALESCE(d.weight,0)) as wgt'),
            DB::raw('SUM(COALESCE(d.amount,0)) as amount'),
        ];

        $rows = $q->select($select)
            ->whereBetween('m.tdate', [$from, $to])
            ->where('m.status', '!=', 0)
            ->groupBy('d.code')
            ->orderByDesc(DB::raw('SUM(COALESCE(d.weight,0))'))
            ->limit(300)
            ->get()
            ->map(fn ($r) => [
                'item_code'  => (string) $r->item_code,
                'item_name'  => (string) $r->item_name,
                'grp_name'   => (string) $r->grp_name,
                'bill_count' => (int) $r->bill_count,
                'qty'        => (float) $r->qty,
                'wgt'        => (float) $r->wgt,
                'amount'     => (float) $r->amount,
            ])
            ->toArray();

        $totals = [
            'qty'    => array_sum(array_column($rows, 'qty')),
            'wgt'    => array_sum(array_column($rows, 'wgt')),
            'amount' => array_sum(array_column($rows, 'amount')),
        ];

        return response()->json(['ok' => true, 'rows' => $rows, 'totals' => $totals]);
    }

    // ══════════════════════════════════════════════════════════════
    //  STAFF / SALESMAN SALES
    // ══════════════════════════════════════════════════════════════

    /** GET /api/owner/staff-sales?from=&to= */
    public function staffSales(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->relaxGroupBy();

        $from = $this->safeDate($request->query('from', ''), date('Y-m-01'));
        $to   = $this->safeDate($request->query('to', ''),   date('Y-m-d'));

        if (!Schema::hasTable('salesm')) {
            return response()->json(['ok' => true, 'rows' => [], 'categories' => [], 'totals' => []]);
        }

        $hasSman = Schema::hasTable('sman');

        $q = DB::table('salesm as m');
        if ($hasSman) {
            $q->leftJoin('sman as s', DB::raw('TRIM(s.code)'), '=', DB::raw('TRIM(m.smcode)'));
        }

        $select = [
            DB::raw('TRIM(m.smcode) as sm_code'),
            $hasSman
                ? DB::raw('COALESCE(TRIM(s.name), TRIM(m.smcode), "—") as sm_name')
                : DB::raw('COALESCE(TRIM(m.smcode),"—") as sm_name'),
            $hasSman
                ? DB::raw('COALESCE(TRIM(s.cat),"") as category')
                : DB::raw('"" as category'),
            DB::raw('COUNT(*) as bill_count'),
            DB::raw('SUM(COALESCE(m.billamt,0)) as bill_amt'),
            DB::raw('SUM(COALESCE(m.discount,0)) as discount'),
            DB::raw('SUM(COALESCE(m.netamt,0)) as net_amt'),
            DB::raw('AVG(COALESCE(m.netamt,0)) as avg_bill'),
        ];

        $rows = $q->select($select)
            ->whereBetween('m.tdate', [$from, $to])
            ->where('m.status', '!=', 0)
            ->groupBy('m.smcode')
            ->orderByDesc(DB::raw('SUM(COALESCE(m.netamt,0))'))
            ->get()
            ->map(fn ($r) => [
                'sm_code'    => (string) $r->sm_code,
                'sm_name'    => (string) $r->sm_name,
                'category'   => (string) $r->category,
                'bill_count' => (int) $r->bill_count,
                'bill_amt'   => (float) $r->bill_amt,
                'discount'   => (float) $r->discount,
                'net_amt'    => (float) $r->net_amt,
                'avg_bill'   => (float) $r->avg_bill,
            ])
            ->toArray();

        // Category totals
        $catMap = [];
        foreach ($rows as $r) {
            $cat = $r['category'] ?: 'General';
            if (!isset($catMap[$cat])) {
                $catMap[$cat] = ['category' => $cat, 'bill_count' => 0, 'net_amt' => 0.0, 'sm_count' => 0];
            }
            $catMap[$cat]['bill_count'] += $r['bill_count'];
            $catMap[$cat]['net_amt']    += $r['net_amt'];
            $catMap[$cat]['sm_count']++;
        }
        usort($catMap, fn ($a, $b) => $b['net_amt'] <=> $a['net_amt']);

        $totals = [
            'bill_count' => array_sum(array_column($rows, 'bill_count')),
            'bill_amt'   => array_sum(array_column($rows, 'bill_amt')),
            'discount'   => array_sum(array_column($rows, 'discount')),
            'net_amt'    => array_sum(array_column($rows, 'net_amt')),
        ];

        return response()->json([
            'ok'         => true,
            'rows'       => $rows,
            'categories' => array_values($catMap),
            'totals'     => $totals,
        ]);
    }

    // ══════════════════════════════════════════════════════════════
    //  PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════

    private function extractToken(Request $request): ?string
    {
        $auth = (string) $request->header('Authorization', '');
        if (str_starts_with($auth, 'Bearer ')) return substr($auth, 7);
        return $request->input('token') ?: null;
    }

    private function authenticate(Request $request): ?array
    {
        $token = $this->extractToken($request);
        if (!$token) return null;
        $data = Cache::get("owner_token:{$token}");
        return is_array($data) ? $data : null;
    }

    private function switchDatabase(string $db): void
    {
        $db = trim($db);
        if ($db === '' || $db === config('database.connections.mysql.database', '')) return;
        Config::set('database.connections.mysql.database', $db);
        DB::purge('mysql');
        DB::reconnect('mysql');
    }

    private function applyAuthDatabase(array $auth): void
    {
        $this->switchDatabase((string) ($auth['database'] ?? ''));
    }

    private function relaxGroupBy(): void
    {
        DB::statement("SET SESSION sql_mode=(SELECT REPLACE(@@SESSION.sql_mode,'ONLY_FULL_GROUP_BY',''))");
    }

    private function getGeneral(string $code): string
    {
        try {
            return (string) (DB::table('generals')->where('code', $code)->value('cvalue') ?? '');
        } catch (\Throwable) {
            return '';
        }
    }

    private function getCurrentRates(): array
    {
        if (!Schema::hasTable('ratehistory')) return [];

        // ratehistory stores one row per date with rates as separate columns
        $row = DB::table('ratehistory')->orderByDesc('tdate')->first();
        if (!$row) return [];

        $map = [
            'grate'   => '22K Gold',
            'g18rate' => '18K Gold',
            'g14rate' => '14K Gold',
            'srate'   => 'Silver',
            'thrate'  => '24K TH',
            'prate'   => 'Platinum',
            'bulrate' => 'Bullion',
            'jrate'   => 'Smith Rate',
        ];

        $rates = [];
        foreach ($map as $col => $label) {
            if (!Schema::hasColumn('ratehistory', $col)) continue;
            $val = (float) ($row->$col ?? 0);
            if ($val > 0) {
                $rates[] = ['code' => strtoupper($col), 'label' => $label, 'rate' => $val];
            }
        }

        return $rates;
    }

    private function safeDate(mixed $val, string $fallback): string
    {
        $s = substr(trim((string) $val), 0, 10);
        return (strlen($s) === 10 && strtotime($s)) ? $s : $fallback;
    }

    private function smithFromGoldsmithtransm(string $from, string $to): array
    {
        $hasPn = Schema::hasColumn('goldsmithtransm', 'partyname');
        $hasIw = Schema::hasColumn('goldsmithtransm', 'issuedwgt');
        $hasRw = Schema::hasColumn('goldsmithtransm', 'receivedwgt');

        return DB::table('goldsmithtransm as m')
            ->leftJoin('clients as c', DB::raw('TRIM(c.code)'), '=', DB::raw('TRIM(m.partycode)'))
            ->select(
                DB::raw('TRIM(m.partycode) as code'),
                DB::raw('COALESCE(TRIM(c.name),' . ($hasPn ? 'TRIM(m.partyname),' : '') . 'TRIM(m.partycode)) as name'),
                DB::raw('COALESCE(TRIM(c.mobile),"") as mobile'),
                $hasIw ? DB::raw('COALESCE(m.issuedwgt,0) as issued_wgt')   : DB::raw('0 as issued_wgt'),
                $hasRw ? DB::raw('COALESCE(m.receivedwgt,0) as received_wgt') : DB::raw('0 as received_wgt'),
                ($hasIw && $hasRw)
                    ? DB::raw('(COALESCE(m.issuedwgt,0)-COALESCE(m.receivedwgt,0)) as balance_wgt')
                    : DB::raw('0 as balance_wgt'),
                DB::raw('0 as amount')
            )
            ->whereBetween('m.tdate', [$from, $to])
            ->orderByDesc('balance_wgt')
            ->get()
            ->map(fn ($r) => [
                'code'         => (string) $r->code,
                'name'         => (string) $r->name,
                'mobile'       => (string) $r->mobile,
                'issued_wgt'   => (float) $r->issued_wgt,
                'received_wgt' => (float) $r->received_wgt,
                'balance_wgt'  => (float) $r->balance_wgt,
                'amount'       => (float) $r->amount,
            ])
            ->toArray();
    }

    private function smithFromSmithm(string $from, string $to): array
    {
        return DB::table('smithm as m')
            ->leftJoin('clients as c', DB::raw('TRIM(c.code)'), '=', DB::raw('TRIM(m.smithcode)'))
            ->select(
                DB::raw('TRIM(m.smithcode) as code'),
                DB::raw('COALESCE(TRIM(c.name), TRIM(m.smithcode)) as name'),
                DB::raw('COALESCE(TRIM(c.mobile),"") as mobile'),
                DB::raw('SUM(CASE WHEN UPPER(TRIM(m.ttype))="I" THEN COALESCE(m.netwgt,0) ELSE 0 END) as issued_wgt'),
                DB::raw('SUM(CASE WHEN UPPER(TRIM(m.ttype))="R" THEN COALESCE(m.netwgt,0) ELSE 0 END) as received_wgt'),
                DB::raw('SUM(CASE WHEN UPPER(TRIM(m.ttype))="I" THEN COALESCE(m.netwgt,0) ELSE -COALESCE(m.netwgt,0) END) as balance_wgt'),
                DB::raw('SUM(COALESCE(m.amount,0)) as amount')
            )
            ->whereBetween('m.tdate', [$from, $to])
            ->groupBy('m.smithcode')
            ->orderByDesc('balance_wgt')
            ->get()
            ->map(fn ($r) => [
                'code'         => (string) $r->code,
                'name'         => (string) $r->name,
                'mobile'       => (string) $r->mobile,
                'issued_wgt'   => (float) $r->issued_wgt,
                'received_wgt' => (float) $r->received_wgt,
                'balance_wgt'  => (float) $r->balance_wgt,
                'amount'       => (float) $r->amount,
            ])
            ->toArray();
    }

    private function smithFromClients(): array
    {
        $balCol = Schema::hasColumn('clients', 'wgtbalance') ? 'wgtbalance'
            : (Schema::hasColumn('clients', 'wgtbal') ? 'wgtbal' : null);

        if (!$balCol) return [];

        return DB::table('clients')
            ->select(
                DB::raw('TRIM(code) as code'),
                DB::raw('TRIM(name) as name'),
                DB::raw('COALESCE(TRIM(mobile),"") as mobile'),
                DB::raw('0 as issued_wgt'),
                DB::raw('0 as received_wgt'),
                DB::raw("COALESCE({$balCol},0) as balance_wgt"),
                DB::raw('0 as amount')
            )
            ->whereRaw("UPPER(TRIM(COALESCE(type,''))) IN ('G','GOLDSMITH','SMITH')")
            ->whereRaw("COALESCE({$balCol},0) != 0")
            ->orderByDesc('balance_wgt')
            ->get()
            ->map(fn ($r) => [
                'code'         => (string) $r->code,
                'name'         => (string) $r->name,
                'mobile'       => (string) $r->mobile,
                'issued_wgt'   => 0.0,
                'received_wgt' => 0.0,
                'balance_wgt'  => (float) $r->balance_wgt,
                'amount'       => 0.0,
            ])
            ->toArray();
    }

    // ══════════════════════════════════════════════════════════════
    //  BRANCH MANAGEMENT  (admin only)
    // ══════════════════════════════════════════════════════════════

    private function ensureBranchTable(): void
    {
        if (!Schema::hasTable('owner_branches')) {
            DB::statement("
                CREATE TABLE owner_branches (
                    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    name        VARCHAR(120) NOT NULL,
                    api_url     VARCHAR(255) NOT NULL,
                    db_name     VARCHAR(80)  NOT NULL DEFAULT '',
                    is_active   TINYINT(1)   NOT NULL DEFAULT 1,
                    note        VARCHAR(255)          DEFAULT NULL,
                    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
        }
    }

    private function isAdmin(array $auth): bool
    {
        $code = strtoupper(trim((string) ($auth['user_code'] ?? '')));
        return in_array($code, ['ADMIN', 'MGR', 'DEVELOPER', 'OWNER'], true);
    }

    /** GET /api/owner/admin/branches */
    public function branchList(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        $this->applyAuthDatabase($auth);
        $this->ensureBranchTable();

        $branches = DB::table('owner_branches')
            ->orderBy('id')
            ->get()
            ->map(fn ($r) => [
                'id'        => (int)    $r->id,
                'name'      => (string) $r->name,
                'api_url'   => (string) $r->api_url,
                'db_name'   => (string) $r->db_name,
                'is_active' => (bool)   $r->is_active,
                'note'      => (string) ($r->note ?? ''),
                'created_at'=> (string) $r->created_at,
            ])
            ->toArray();

        return response()->json([
            'ok'       => true,
            'branches' => $branches,
            'is_admin' => $this->isAdmin($auth),
        ]);
    }

    /** POST /api/owner/admin/branches  {name, api_url, db_name?, note?, is_active?} */
    public function branchCreate(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        if (!$this->isAdmin($auth)) {
            return response()->json(['ok' => false, 'message' => 'Admin access required'], 403);
        }
        $this->applyAuthDatabase($auth);
        $this->ensureBranchTable();

        $name    = trim((string) ($request->input('name') ?? ''));
        $apiUrl  = trim((string) ($request->input('api_url') ?? ''));
        $dbName  = trim((string) ($request->input('db_name') ?? ''));
        $note    = trim((string) ($request->input('note') ?? ''));
        $active  = $request->boolean('is_active', true);

        if ($name === '' || $apiUrl === '') {
            return response()->json(['ok' => false, 'message' => 'Name and API URL are required'], 400);
        }

        $id = DB::table('owner_branches')->insertGetId([
            'name'      => $name,
            'api_url'   => rtrim($apiUrl, '/'),
            'db_name'   => $dbName,
            'note'      => $note ?: null,
            'is_active' => $active ? 1 : 0,
        ]);

        return response()->json(['ok' => true, 'id' => $id, 'message' => 'Branch created']);
    }

    /** PUT /api/owner/admin/branches/{id}  {name?, api_url?, db_name?, note?, is_active?} */
    public function branchUpdate(Request $request, int $id): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        if (!$this->isAdmin($auth)) {
            return response()->json(['ok' => false, 'message' => 'Admin access required'], 403);
        }
        $this->applyAuthDatabase($auth);
        $this->ensureBranchTable();

        $row = DB::table('owner_branches')->where('id', $id)->first();
        if (!$row) {
            return response()->json(['ok' => false, 'message' => 'Branch not found'], 404);
        }

        $data = [];
        if ($request->has('name'))      $data['name']      = trim((string) $request->input('name'));
        if ($request->has('api_url'))   $data['api_url']   = rtrim(trim((string) $request->input('api_url')), '/');
        if ($request->has('db_name'))   $data['db_name']   = trim((string) $request->input('db_name'));
        if ($request->has('note'))      $data['note']      = trim((string) $request->input('note')) ?: null;
        if ($request->has('is_active')) $data['is_active'] = $request->boolean('is_active') ? 1 : 0;

        if (empty($data)) {
            return response()->json(['ok' => false, 'message' => 'Nothing to update'], 400);
        }

        DB::table('owner_branches')->where('id', $id)->update($data);

        return response()->json(['ok' => true, 'message' => 'Branch updated']);
    }

    /** DELETE /api/owner/admin/branches/{id} */
    public function branchDelete(Request $request, int $id): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }
        if (!$this->isAdmin($auth)) {
            return response()->json(['ok' => false, 'message' => 'Admin access required'], 403);
        }
        $this->applyAuthDatabase($auth);
        $this->ensureBranchTable();

        $deleted = DB::table('owner_branches')->where('id', $id)->delete();

        if (!$deleted) {
            return response()->json(['ok' => false, 'message' => 'Branch not found'], 404);
        }

        return response()->json(['ok' => true, 'message' => 'Branch deleted']);
    }

    /** GET /api/owner/admin/branches/test-connection?api_url= */
    public function branchTestConnection(Request $request): JsonResponse
    {
        if (!$auth = $this->authenticate($request)) {
            return response()->json(['ok' => false, 'message' => 'Unauthorised'], 401);
        }

        $apiUrl = rtrim(trim((string) ($request->query('api_url') ?? '')), '/');
        if ($apiUrl === '') {
            return response()->json(['ok' => false, 'message' => 'api_url required'], 400);
        }

        try {
            $ch = curl_init("{$apiUrl}/api/owner/shop-info");
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 8,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => false,
            ]);
            $body   = curl_exec($ch);
            $code   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error  = curl_error($ch);
            curl_close($ch);

            if ($error) {
                return response()->json(['ok' => false, 'message' => "Connection failed: {$error}"]);
            }
            if ($code !== 200) {
                return response()->json(['ok' => false, 'message' => "Server returned HTTP {$code}"]);
            }
            $data = json_decode($body, true);
            $shopName = $data['shop_name'] ?? 'Unknown';

            return response()->json(['ok' => true, 'message' => "Connected — {$shopName}", 'shop_name' => $shopName]);
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }
}
